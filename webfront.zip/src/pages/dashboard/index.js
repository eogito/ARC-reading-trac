import React, { useState } from 'react'

import { useCallback } from 'react'
import { useEffect } from 'react'
import { useParams} from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
// material-ui
import {InputLabel, Stack, Grid, Paper, Typography, LinearProgress, Box, IconButton, Button} from '@mui/material'
import {red, blue} from '@mui/material/colors'

// project import
import MainCard from 'components/MainCard'
import ScrollX from 'components/ScrollX'
import { SnackbarProvider } from 'notistack'
import Breadcrumbs from "../../components/@extended/Breadcrumbs"
import WhatshotIcon from '@mui/icons-material/Whatshot';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import PostAddIcon from '@mui/icons-material/PostAdd';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { getSessionMemberApi } from 'api/AuthApi'
import {
  DebouncedInput
} from 'components/third-party/react-table' // HeaderSort
import Avatar from 'components/@extended/Avatar'
import BookProgressApi from 'api/BookProgressApi'
import BookApi from 'api/BookApi'

// ==============================|| DASHBOARD - DEFAULT ||============================== //

const DashboardDefault = () => {
  let newl =[]
  const navigate = useNavigate()
  const [userId, setUserId] = useState(1)
  const [books, setBooks] = useState([]);
  const [data, setData] = useState([]);
  const [text, setText] = useState("")
  const [checked, setChecked] = React.useState(false);

  const handleCheck = (event) => {
    setChecked(event.target.checked);
    console.log(checked)
  }
  const getBooks = useCallback(async () => {
    const curUser = await getSessionMemberApi()
    let newl = []
    console.log(curUser.id)
    let temp = curUser.id
    setUserId(temp)
    console.log(userId)
    try {
        const result = await BookProgressApi.getAll()
        if (result) {
            _.forEach(result, book => {
                if (book.userId == userId) {
                    newl.push(book)
                    console.log(book)
                }
            })
            setData(newl)
            console.log(data)
        }
    } catch (error) {
        console.log(error)
    }
}, [])
  useEffect(() => {
    getBooks()
  }, [getBooks])
  
  return (
    <>
      <Breadcrumbs custom heading='Dashboard' />
        <MainCard>
            <ScrollX>
                <Stack spacing={2.5}>
                  <Grid container spacing ={0} justifyContent="space-evenly" alignItems="center">
                    <Paper xs={15} elevation={3} sx={{ margin: 2, padding:2, width: 1}}>
                      <Stack direction="row">
                        <Avatar sx={{ width: 1/4, height: 1/4, margin: 3}} src = "https://cdn.pixabay.com/photo/2023/01/18/10/32/ouch-7726461_640.jpg"></Avatar>
                        <Stack spacing={2.5}>
                          <Typography sx={{pt:5}} variant="h1">
                            Glen Lin
                          </Typography>
                          <Typography sx={{}} variant="h3">
                            Level 4
                          </Typography>
                          <LinearProgress sx={{width: '100%'}}variant="determinate" value={60} />
                          <Stack direction="row" sx={{}}>
                            <WhatshotIcon sx={{fontSize:100, color: red[500]}}/>
                            <Typography variant="h2" sx={{pl: 1, pt: 4.1}}>
                              Streak: 15 days
                            </Typography>
                          </Stack>
                        </Stack>
                        <Stack spacing={7.8} justifyContent="center" sx={{pl: 2}}>
                          <Stack direction="row">
                            <CollectionsBookmarkIcon sx={{fontSize:100, color: blue[500]}}/>
                            <Typography variant="h2" sx={{pl: 1, pt: 4.1}}>
                              Books read: 7
                            </Typography>
                          </Stack>
                          <Stack direction="row" sx={{}}>
                            <PostAddIcon sx={{fontSize:100, color: blue[500]}}/>
                            <Typography variant="h2" sx={{pl: 1, pt: 4.1}}>
                              Pages read: 941
                            </Typography>
                          </Stack>
                        </Stack>
                      </Stack>
                    </Paper>
                    
                    <Paper xs={15} elevation={3} sx={{ margin: 2, padding:2, width: 1}}>
                      <Stack direction="row" alignItems="center" justifyContent="space-between">
                        <IconButton aria-label="back">
                          <ArrowBackIcon/>
                        </IconButton>
                        <Box
                          component="img"
                          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT395Rz6i1lYOC8swNa0yloAbZjUs5Fl2oNVA&s"
                          sx={{pl: 10}}
                        />
                        <Stack spacing={1} sx={{pl:3}}>
                          <Typography sx={{pt:5}} variant="h1">
                            The Understory
                          </Typography>
                          <Typography sx={{}} variant="h3">
                            Saneh Sangsuk
                          </Typography>
                          <LinearProgress sx={{width: '100%'}}variant="determinate" value={60} />
                          <Typography sx={{}} variant="h6">
                            60%
                          </Typography>
                        </Stack>
                        <Stack spacing={3} sx={{pl:5}} justifyContent="center">
                          <Button 
                            onClick={() => {
                              navigate('/add')
                            }}
                          variant="contained" size="large">New Book</Button>
                          <Button 
                          onClick={() => {
                            navigate('/update')
                          }}
                          variant="contained" size="large">Update Progress</Button>
                        </Stack>
                        <Stack direction="row" justifyContent="flex-end">
                          <IconButton aria-label="back">
                            <ArrowForwardIcon/>
                          </IconButton>
                        </Stack>
                      </Stack>
                    </Paper>
                    <Paper xs={15} elevation={3} sx={{ margin: 2, padding:2, width: 1}}>
                      <Stack alignItems="center" justifyContent="center" spacing={2}>
                        <Typography variant="h1">
                          Progress Summary
                        </Typography>
                        {data.map(book => (
                          <Box sx={{width:1, border:'2px solid gray', background: '#d1d1d1', padding:2}}>
                            <Stack direction="row" justifyContent="space-between" alignItems="flex-begin">
                              <Typography variant="h4">
                                Cool Title
                              </Typography>
                              <Typography variant="h4">
                                12521
                              </Typography>
                            </Stack>
                            <Stack justifyContent="ceneter" alignItems="flex-begin" sx={{pt:2}}>
                              <Typography variant="h4">
                                Pages Read: 32
                              </Typography>
                              <Typography variant="h4">
                                Note: I really like chapter 4 off this novel. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ac nulla nec velit egestas ullamcorper. Sed rhoncus urna urna. Fusce auctor iaculis enim, vel tempus arcu ornare sed. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Vestibulum dictum tristique facilisis. Maecenas dapibus faucibus aliquam. Pellentesque eleifend tortor in venenatis eleifend.
                              </Typography>
                            </Stack>
                          </Box>
                        ))} 
                              
                      </Stack>
                    </Paper>
                  </Grid>
                </Stack>
            </ScrollX>
        </MainCard>     
        <SnackbarProvider/>
    </>
  )
}

export default DashboardDefault

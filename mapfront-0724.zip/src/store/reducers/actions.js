// action - account reducer
export const LOGIN = '@auth/LOGIN'
export const LOGOUT = '@auth/LOGOUT'

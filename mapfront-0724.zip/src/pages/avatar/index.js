import React, { useState } from 'react'

import { useCallback } from 'react'
import { useEffect } from 'react'
import { useParams} from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
// material-ui
import {InputLabel, Stack, Grid, Paper, Typography, LinearProgress, Box, IconButton, Button} from '@mui/material'
import {red, blue} from '@mui/material/colors'

// project import
import MainCard from 'components/MainCard'
import ScrollX from 'components/ScrollX'
import { SnackbarProvider } from 'notistack'
import Breadcrumbs from "../../components/@extended/Breadcrumbs"
import WhatshotIcon from '@mui/icons-material/Whatshot';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import PostAddIcon from '@mui/icons-material/PostAdd';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { getSessionMemberApi } from 'api/AuthApi'
import {
  DebouncedInput
} from 'components/third-party/react-table' // HeaderSort
import Avatar from 'components/@extended/Avatar'
import BookProgressApi from 'api/BookProgressApi'
import BookApi from 'api/BookApi'
import UserApi from 'api/UserApi'
import AvatarApi from 'api/AvatarApi'

// ==============================|| DASHBOARD - DEFAULT ||============================== //

const AvatarSelection = () => {
  let newl =[]
  const navigate = useNavigate()
  const [index, setIndex] = useState(0)
  const [level, setLevel] = useState(1)
  const [user, setUser] = useState()
  const [data, setData] = useState([])
  const [books, setBooks] = useState([])
  const [checked, setChecked] = React.useState(false)
  const [loading, setLoading] = useState(false)

  const handleCheck = (event) => {
    setChecked(event.target.checked);
    console.log(checked)
  }
  const getBooks = useCallback(async () => {
    const curUser = await getSessionMemberApi()
    let newl = []
    let neww = []
    console.log(curUser.id)
    let temp = curUser.id
    //setUserId(temp)
    //console.log(userId)
    try {
        const result = await AvatarApi.getAll()
        if (result) {
            setData(result)
            setLoading(true)
        }
    } catch (error) {
        console.log(error)
    }
}, [])
  useEffect(() => {
    getBooks()
  }, [getBooks])
  
  return (
    <>
      <Breadcrumbs custom heading='Avatar' />
        <MainCard>
            {(loading) &&
            <ScrollX>
                <Stack spacing={2.5}>
                  <Grid container spacing ={0} justifyContent="space-evenly" alignItems="center">
                    <Paper xs={15} elevation={3} sx={{ margin: 2, padding:2, width: 1}}>
                      <Stack direction="row"  justifyContent="space-evenly" alignItems="center">
                        {data.map(avatar => (
                            <Stack spacing={2} justifyContent="space-evenly" alignItems="center" >
                                <Avatar sx={{ width: 200, height: 200, margin: 3}} src = {avatar.avatarUrl}></Avatar>
                                <Stack spacing={2.5}>
                                    <Typography sx={{pt:5}} variant="h5">
                                        {avatar.avatarName}, Level {avatar.levelReq} Required
                                    </Typography>
                                </Stack>
                            </Stack>
                        ))}
                      </Stack>
                    </Paper>
                    
                  </Grid>
                </Stack>
            </ScrollX>
          }
        </MainCard>     
        <SnackbarProvider/>
    </>
  )
}

export default AvatarSelection

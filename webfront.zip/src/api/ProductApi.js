import axiosHttp from './axiosHttp'
export default {
    async getProductById(id) {
        try {
            const url = '/product/' + id

            const result = await axiosHttp.get(url)
            if (result && result.data) {
                return result.data
            }
        } catch (error) {
            console.log(error.response.data)
            // dispatch({ type: USER_SIGNIN_FAIL, payload: error.message })
        }
    },

    async search(filter, sortingOption, offset, limit){
        let filterStr = '{}'
        let sortingstr = '{}'
        if (filter) {
            filterStr = JSON.stringify(filter)
        }
        if (sortingOption) {
            sortingstr = JSON.stringify(sortingOption)
        }
        try {
            const url = '/product/search'
            const params = {
                filter: filterStr,
                sorting: sortingstr,
                offset: offset,
                limit: limit
            }
            const result = await axiosHttp.post(url, params)
            if (result && result.data) {
                return {
                    totalCount: parseInt(result.headers['x-total-count']),
                    data: result.data
                }
            }
        } catch (error) {
            console.log(error)
            console.log(error.response.data)
            // dispatch({ type: USER_SIGNIN_FAIL, payload: error.message })
        }
    },
    async findAllByCategoryId(categoryId){
        const filter = {
            categoryId: categoryId
        }
        const sortingOption = {
            'name': 'ASC'
        }
        const offset = 0
        const limit = 500
        const results = await this.search(filter, sortingOption, offset, limit)
        if (results && results.data) {
            return results.data
        } else {
            return []
        }
    },
    async update(id, product) {
        try {
            const url = '/product/' + id
            const result = await axiosHttp.put(url, product)
            return result
        } catch (error) {
            console.log(error)
            return error.response.data
            // dispatch({ type: USER_SIGNIN_FAIL, payload: error.message })
        }
    },

    async create(product) {
        try {
            const url = '/product'
            const result = await axiosHttp.post(url, product)
            return result
        } catch (error) {
            console.log(error)
            return error.response.data
            // dispatch({ type: USER_SIGNIN_FAIL, payload: error.message })
        }
    },
    async getAllProducts() {
        try {
            const url = '/product'
            const result = await axiosHttp.get(url)
            if (result && result.data) {
                return result.data
            }
        } catch (error) {
            return []
        }
    }
}